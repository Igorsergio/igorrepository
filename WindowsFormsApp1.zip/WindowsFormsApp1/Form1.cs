﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[,] M = new int[6, 6];//seis linha seis colunas
        private void Form1_Load(object sender, EventArgs e)
        {
            for (int L = 0; L < 6; L++)
            {
                for (int C = 0; C <= 6; C++)
                {
                    M[L, C] = new Random().Next(100);
                }
            }//carrega matriz com números inteiros
            //aleatótios de 0 a 100

        }

        private void button7_Click(object sender, EventArgs e)
        {
            //row
            string linha=string.Empty;
            for (int L = 0; L < 6; L++)
            {
                for (int C = 0; C < 6; C++)
                {
                    linha += M[L,C].ToString()+ "  ";
                }
                listBox1.Items.Add(linha);
                linha = string.Empty;
            }
        }
    }
}
