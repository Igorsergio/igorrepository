﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[,] M = new int[6, 6];//seis linha seis colunas
        string[] times = { "A1", "B4", "D7", "F5","G8"};
        int numero;
        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int L = 0; L < 6; L++)
            {
                for (int C = 0; C < 6; C++)
                {
                    M[L, C] = new Random().Next(100);
                }//carrega matriz com números inteiros
                 //aleatótios de 0 a 100
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            //row
            //string linha=string.Empty;
            //for (int L = 0; L < 6; L++)
            //{
            //    for (int C = 0; C < 6; C++)
            //    {
            //        linha += M[L,C].ToString()+ "  ";
            //    }
            //    listBox1.Items.Add(linha);
            //    linha = string.Empty;

            for (int i = 0; i < times.Length; i++)
            {
                times[i] = new Random().Next() + "H9";

            }
           


            foreach (var linha in M)
            {

            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            //for (int i = 0; i < times.Length; i++)
            //{
            //    listBox1.Items.Add(times[i]);
            //}
            foreach (var time in times)
            {
                listBox1.Items.Add(time);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //apresentar no listbox  a tabuada de um  número informado pelo usuario. 
            //deve ser armazenado em matriz de uma dimensão.
            int n1, n2;
       

            n1 = int.Parse(textBox1.Text);
            for (int i = 1; i <= 10; i++)
            {
                n2 = n1 * i;

                listBox1.Items.Add(n1 +" x "+ i + " = " + n2);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }    
    }
}

    
